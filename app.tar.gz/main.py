import flet as ft
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

def main(pagina: ft.Page):
    pagina.title = "Teste Flet."
    pagina.vertical_alignment = ft.MainAxisAlignment.START
    pagina.window_width = 450
    pagina.window_height = 750
    
    def send(nome, idade, sexo, obs):
        # Configurações do remetente
        remetente_email = "memeshaha132@gmail.com"
        remetente_senha = "kcqw zzvu fqwa gllh"

        # Configurações do destinatário
        destinatario_email = "thiagolcsalves@gmail.com"

        # Configurações do servidor SMTP do Gmail
        smtp_servidor = "smtp.gmail.com"
        smtp_porta = 587

        # Criação da mensagem
        assunto = f"Informações do paciente: {nome}"
        corpo = f"Nome completo: {nome} \nIdade: {idade} \nSexo: {sexo} \nObservações importantes: {obs}"

        mensagem = MIMEMultipart()
        mensagem['From'] = remetente_email
        mensagem['To'] = destinatario_email
        mensagem['Subject'] = assunto
        mensagem.attach(MIMEText(corpo, 'plain'))

        # Conexão com o servidor SMTP
        try:
            servidor_smtp = smtplib.SMTP(smtp_servidor, smtp_porta)
            servidor_smtp.starttls()  # Inicia a camada de segurança TLS
            servidor_smtp.login(remetente_email, remetente_senha)
            
            # Envio do e-mail
            servidor_smtp.sendmail(remetente_email, destinatario_email, mensagem.as_string())
            
            print("E-mail enviado com sucesso!")

        except Exception as e:
            print("Erro ao enviar o e-mail:", str(e))

        finally:
            # Fecha a conexão com o servidor SMTP
            if servidor_smtp:
                servidor_smtp.quit()
    
    #Funções
    def enviar(e):
        if not name_box.value:
            name_box.error_text = "Digite todas as informações!"
            pagina.update()
        else:
            pagina.update()
            nome = name_box.value
            idade = age_box.value
            sexo = sex_box.value
            obs = obs_box.value
            send(nome, idade, sexo, obs)
            output_text.value = "Informações enviadas com sucesso!"
            pagina.update()
        
    #Estrutura visual
    name_box = ft.TextField(label="Seu nome completo*")
    age_box = ft.TextField(label="Sua idade*")
    sex_box = ft.Dropdown(
        label = "Sexo*",
        width = 120,
        options=[
            ft.dropdown.Option("Masculino"),
            ft.dropdown.Option("Feminino"),
        ],
    )
    obs_box = ft.TextField(
        label="Observações",
        multiline=True,
        min_lines=1,
        max_lines=3,
        )
    send_button = ft.ElevatedButton("Enviar", on_click=enviar)
    output_text = ft.Text()
    img = ft.Image(
        src='assets/b12logo.png',
        width=100,
        height=100,
        fit=ft.ImageFit.CONTAIN,
    )
    
    #Inserir elementos na pagina
    pagina.add(
        ft.ResponsiveRow(col=6, controls=[
            img,
            name_box,
            age_box,
            sex_box,
            obs_box,
            send_button,
        ], alignment=ft.MainAxisAlignment.CENTER),
        
        ft.ResponsiveRow(col=6, controls=[
            output_text
        ], vertical_alignment=ft.MainAxisAlignment.CENTER)
    )

ft.app(target=main,assets_dir="assets")